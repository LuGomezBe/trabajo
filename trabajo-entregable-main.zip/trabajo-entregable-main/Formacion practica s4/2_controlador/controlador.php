
<?php

class McvControlador{
    public function plantilla(){
        include "1_vista/plantilla.php";
    }
    public function login(){
            include "1_vista/login.php";
    } 
}
?>
