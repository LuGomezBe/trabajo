<footer class="footer">
        <div class="container footer__grid">
            <nav class="nav nav--footer">
                <a class="nav__items nav__items--footer" href="">Inicio</a>
                <a class="nav__items nav__items--footer" href="">Servicios</a>
                <a class="nav__items nav__items--footer" href="">Trabajos</a>
                <a class="nav__items nav__items--footer" href="">Proyectos</a>
            </nav>

            <section class="footer__contact">
                <h3 class="footer__title">Contactanos</h3>
                <div class="footer__icons">
                    <span class="footer__container-icons">
                        <a class="fa-brands fa-facebook-f footer__icon" href="#"></a>
                    </span>

                    <span class="footer__container-icons">
                        <a class="fa-brands fa-instagram footer__icon" href="#"></a>
                    </span>

                    <span class="footer__container-icons">
                        <a class="fa-brands fa-whatsapp footer__icon" href="#"></a>
                    </span>

                </div>
            </section>
        </div>
    </footer>